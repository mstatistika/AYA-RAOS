#!/bin/bash
# AYA RAOS — Merge Integration Branch + Apply Preview Mode
# Run this in GitHub Codespace terminal

set -e

echo "🚀 AYA RAOS Admin Merge Script"
echo "================================"

# 1. Checkout folders from integration branch
echo "📦 Copying admin/, api/, server/, supabase/ from integration branch..."
git checkout integration/backend-admin-mobile-20260822 -- admin/ api/ server/ supabase/

# 2. Apply modified files (bypass login, loading states, font fixes)
echo "🔧 Applying preview mode modifications..."

# Backup original files
cp admin/index.html admin/index.html.bak
cp admin/app.js admin/app.js.bak
cp vercel.json vercel.json.bak 2>/dev/null || true

# Replace with preview versions
# NOTE: Place the downloaded files in the repo root first, then run:
# cp /path/to/downloaded/index.html admin/index.html
# cp /path/to/downloaded/app.js admin/app.js
# cp /path/to/downloaded/vercel.json vercel.json

# Append CSS additions
cat admin-css-additions.css >> admin/admin.css

echo "✅ Files merged!"
echo ""
echo "Next steps:"
echo "1. Replace admin/index.html with the downloaded version"
echo "2. Replace admin/app.js with the downloaded version"
echo "3. Replace vercel.json with the downloaded version"
echo "4. Run: git add . && git commit -m 'merge: admin panel with preview mode' && git push"
echo ""
echo "Then visit: https://aya-raos.vercel.app/admin/"
